#include <iostream>

int main()
{
    std::cout << "Hello World!\n";
}

// Compile with: cl /EHsc .\main.cpp .\hello.cpp
