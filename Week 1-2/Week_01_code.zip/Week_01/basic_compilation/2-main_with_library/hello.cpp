#include <iostream>
#include "hello.h"

void say_hello(){
  std::cout << "Hello World!\n";
}
