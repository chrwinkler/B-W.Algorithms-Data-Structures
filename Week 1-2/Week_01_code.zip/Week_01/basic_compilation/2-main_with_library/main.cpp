#include "hello.h"

int main()
{
    say_hello();
    return 0;
}

// Compile with: cl /EHsc .\main.cpp .\hello.cpp
