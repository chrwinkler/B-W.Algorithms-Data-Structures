void Hello::say_hello(){
  std::cout << greeting << "\n";
}
